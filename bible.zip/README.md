# Bible - King James Version

+ Contains all the 66 books of the Old Testament and New Testament
+ Each book is in a separate JSON file as a JSON object
+ `Books.json` contains all 66 book names as a JSON array
